import sys
from src.cli import cli 
if __name__ == "__main__":
    print("1")
    cli()
# print(dir(src.cli))