import sys
from src.weather import WeatherClient
client = WeatherClient('北京')
# print(client.get_weather())
print(sys.path)